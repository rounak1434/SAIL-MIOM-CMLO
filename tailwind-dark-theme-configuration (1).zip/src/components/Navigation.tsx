interface NavigationProps {
  currentPage: 'dashboard' | 'analytics' | 'cases' | 'submit';
  onNavigate: (page: 'dashboard' | 'analytics' | 'cases' | 'submit') => void;
}

export default function Navigation({ currentPage, onNavigate }: NavigationProps) {
  return (
    <nav className="fixed top-0 w-full z-50 bg-slate-950/40 backdrop-blur-xl border-b border-white/10 flex justify-between items-center px-8 h-20 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
      <div className="flex items-center gap-8">
        <button 
          onClick={() => onNavigate('submit')}
          className="text-2xl font-bold bg-gradient-to-br from-blue-400 to-indigo-400 bg-clip-text text-transparent font-headline tracking-tight hover:opacity-80 transition-opacity"
        >
          The Arbiter
        </button>
        <div className="hidden md:flex gap-6 items-center">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`font-headline transition-colors duration-300 ${
              currentPage === 'dashboard' ? 'text-blue-300' : 'text-slate-400 hover:text-blue-300'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onNavigate('analytics')}
            className={`font-headline transition-colors duration-300 ${
              currentPage === 'analytics' ? 'text-blue-300' : 'text-slate-400 hover:text-blue-300'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => onNavigate('cases')}
            className={`font-headline transition-colors duration-300 ${
              currentPage === 'cases' ? 'text-blue-300' : 'text-slate-400 hover:text-blue-300'
            }`}
          >
            Cases
          </button>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <button className="text-slate-400 hover:text-blue-300 transition-colors">
          <span className="material-symbols-outlined">notifications</span>
        </button>
        <button className="text-slate-400 hover:text-blue-300 transition-colors">
          <span className="material-symbols-outlined">settings</span>
        </button>
        <div className="w-10 h-10 rounded-full overflow-hidden border border-outline-variant/30 bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
          A
        </div>
      </div>
    </nav>
  );
}
