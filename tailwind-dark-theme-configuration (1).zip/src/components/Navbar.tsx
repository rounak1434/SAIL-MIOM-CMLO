import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { logoutUser } from '../services/auth.service';
import { collection, query, where, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { Menu, X, Bell, User, LogOut, LayoutDashboard } from 'lucide-react';

interface Notification {
  id: string;
  message: string;
  type: string;
  read: boolean;
  createdAt: string;
}

export const Navbar = () => {
  const { currentUser, userRole } = useAuth();
  const navigate = useNavigate();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Scroll detection for enhanced navbar effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'notifications'),
      where('userEmail', '==', currentUser.email)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notificationsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Notification[];
      setNotifications(notificationsData.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    });

    return () => unsubscribe();
  }, [currentUser]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleLogout = async () => {
    await logoutUser();
    navigate('/');
    setShowProfileMenu(false);
    setMobileMenuOpen(false);
  };

  const markAsRead = async (notificationId: string) => {
    await updateDoc(doc(db, 'notifications', notificationId), {
      read: true
    });
  };

  const markAllAsRead = async () => {
    const unreadNotifications = notifications.filter(n => !n.read);
    await Promise.all(
      unreadNotifications.map(n => 
        updateDoc(doc(db, 'notifications', n.id), { read: true })
      )
    );
  };

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 border-b ${
      scrolled 
        ? 'bg-slate-900/90 backdrop-blur-2xl border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.4)]' 
        : 'bg-slate-900/75 backdrop-blur-xl border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.3)]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center z-50">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="text-xl sm:text-2xl font-bold bg-gradient-to-br from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent font-headline tracking-tight whitespace-nowrap"
            >
              SAIL-MIOM
            </motion.div>
          </Link>

          {/* Center Navigation - Desktop */}
          <div className="hidden md:flex items-center gap-6 lg:gap-8">
            <Link to="/">
              <motion.div
                whileHover={{ y: -2 }}
                className="relative text-slate-300 hover:text-white transition-colors font-medium group text-sm lg:text-base"
              >
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 group-hover:w-full transition-all duration-300"></span>
              </motion.div>
            </Link>
            <Link to="/file-complaint">
              <motion.div
                whileHover={{ y: -2 }}
                className="relative text-slate-300 hover:text-white transition-colors font-medium group text-sm lg:text-base"
              >
                File Complaint
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 group-hover:w-full transition-all duration-300"></span>
              </motion.div>
            </Link>
            <Link to="/track-complaint">
              <motion.div
                whileHover={{ y: -2 }}
                className="relative text-slate-300 hover:text-white transition-colors font-medium group text-sm lg:text-base"
              >
                Track Complaint
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 group-hover:w-full transition-all duration-300"></span>
              </motion.div>
            </Link>
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-2 sm:gap-4">
            {!currentUser ? (
              <>
                {/* Desktop Login Buttons */}
                <div className="hidden md:flex items-center gap-2 lg:gap-3">
                  <Link to="/login">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-3 lg:px-4 py-2 rounded-lg glass-card hover:glass-strong transition-all text-white font-medium text-sm whitespace-nowrap"
                    >
                      Admin Login
                    </motion.button>
                  </Link>
                  <Link to="/moderator-login">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-3 lg:px-4 py-2 rounded-lg glass-button text-white font-medium text-sm whitespace-nowrap"
                    >
                      Moderator Login
                    </motion.button>
                  </Link>
                </div>

                {/* Mobile Hamburger */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-2 rounded-lg glass-card hover:glass-strong transition-all text-white"
                >
                  {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </>
            ) : (
              <>
                {/* Logged In User - Desktop */}
                <div className="hidden md:flex items-center gap-3">
                  {/* Dashboard Link */}
                  <Link to={userRole && userRole.role === 'admin' ? '/dashboard' : '/moderator-dashboard'}>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-lg glass-button text-white font-medium text-sm whitespace-nowrap flex items-center gap-2"
                    >
                      <LayoutDashboard className="w-4 h-4" />
                      Dashboard
                    </motion.button>
                  </Link>

                  {/* Notifications */}
                  <div className="relative">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        setShowNotifications(!showNotifications);
                        setShowProfileMenu(false);
                      }}
                      className="relative p-2 rounded-lg glass-card hover:glass-strong transition-all text-white"
                    >
                      <Bell className="w-5 h-5" />
                      {unreadCount > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full text-xs font-bold flex items-center justify-center text-white">
                          {unreadCount}
                        </span>
                      )}
                    </motion.button>

                    <AnimatePresence>
                      {showNotifications && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 mt-2 w-80 glass-strong rounded-2xl shadow-2xl overflow-hidden"
                        >
                          <div className="p-4 border-b border-white/10 flex items-center justify-between">
                            <h3 className="font-bold text-white">Notifications</h3>
                            {unreadCount > 0 && (
                              <button
                                onClick={markAllAsRead}
                                className="text-xs text-blue-400 hover:text-blue-300"
                              >
                                Mark all read
                              </button>
                            )}
                          </div>
                          <div className="max-h-96 overflow-y-auto">
                            {notifications.length === 0 ? (
                              <div className="p-8 text-center text-slate-400">
                                No notifications yet
                              </div>
                            ) : (
                              notifications.map(notification => (
                                <div
                                  key={notification.id}
                                  onClick={() => markAsRead(notification.id)}
                                  className={`p-4 border-b border-white/5 cursor-pointer hover:bg-white/5 transition-colors ${
                                    !notification.read ? 'bg-blue-500/10' : ''
                                  }`}
                                >
                                  <p className="text-sm text-white mb-1">{notification.message}</p>
                                  <p className="text-xs text-slate-400">
                                    {new Date(notification.createdAt).toLocaleString()}
                                  </p>
                                </div>
                              ))
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Profile */}
                  <div className="relative">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setShowProfileMenu(!showProfileMenu);
                        setShowNotifications(false);
                      }}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg glass-card hover:glass-strong transition-all text-white"
                    >
                      <User className="w-5 h-5" />
                      <span className="text-sm font-medium hidden lg:block">
                        {currentUser?.email?.split('@')[0]}
                      </span>
                    </motion.button>

                    <AnimatePresence>
                      {showProfileMenu && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 mt-2 w-48 glass-strong rounded-xl shadow-2xl overflow-hidden"
                        >
                          <div className="p-3 border-b border-white/10">
                            <p className="text-xs text-slate-400">Signed in as</p>
                            <p className="text-sm font-medium text-white truncate">
                              {currentUser?.email}
                            </p>
                            <p className="text-xs text-blue-400 capitalize mt-1">{userRole?.role}</p>
                          </div>
                          <button
                            onClick={handleLogout}
                            className="w-full p-3 text-left hover:bg-white/10 transition-colors flex items-center gap-2 text-white"
                          >
                            <LogOut className="w-4 h-4" />
                            <span className="text-sm">Logout</span>
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Mobile Hamburger for Logged In */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-2 rounded-lg glass-card hover:glass-strong transition-all text-white"
                >
                  {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-strong border-t border-white/10"
          >
            <div className="px-4 py-4 space-y-3">
              {/* Navigation Links */}
              <Link
                to="/"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-lg glass-card hover:glass-strong transition-all text-white font-medium"
              >
                Home
              </Link>
              <Link
                to="/file-complaint"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-lg glass-card hover:glass-strong transition-all text-white font-medium"
              >
                File Complaint
              </Link>
              <Link
                to="/track-complaint"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-lg glass-card hover:glass-strong transition-all text-white font-medium"
              >
                Track Complaint
              </Link>

              {!currentUser ? (
                <>
                  <Link
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block px-4 py-3 rounded-lg glass-button text-white font-medium text-center"
                  >
                    Admin Login
                  </Link>
                  <Link
                    to="/moderator-login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block px-4 py-3 rounded-lg glass-button text-white font-medium text-center"
                  >
                    Moderator Login
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    to={userRole && userRole.role === 'admin' ? '/dashboard' : '/moderator-dashboard'}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block px-4 py-3 rounded-lg glass-button text-white font-medium flex items-center gap-2"
                  >
                    <LayoutDashboard className="w-5 h-5" />
                    Dashboard
                  </Link>
                  <div className="px-4 py-3 glass-card rounded-lg">
                    <p className="text-xs text-slate-400 mb-1">Signed in as</p>
                    <p className="text-sm font-medium text-white">{currentUser?.email}</p>
                    <p className="text-xs text-blue-400 capitalize mt-1">{userRole?.role}</p>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="w-full px-4 py-3 rounded-lg glass-card hover:glass-strong transition-all text-white font-medium flex items-center gap-2"
                  >
                    <LogOut className="w-5 h-5" />
                    Logout
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
