import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Clock, TrendingUp, CheckCircle, XCircle, Users, 
  Trash2, Eye, UserPlus, Mail, Phone, Building2, Lock, User
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { 
  subscribeToAllComplaints, 
  subscribeToComplaintStats, 
  Complaint,
  ComplaintStats,
  deleteComplaint,
  updateComplaintStatus,
  assignComplaint,
  updateAdminNote
} from '../services/complaint.service';
import { 
  createModeratorAccount, 
  getAllModerators, 
  deleteModerator,
  Moderator 
} from '../services/moderator.service';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [stats, setStats] = useState<ComplaintStats>({
    total: 0,
    pending: 0,
    assigned: 0,
    active: 0,
    resolved: 0,
    rejected: 0
  });
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [showModeratorForm, setShowModeratorForm] = useState(false);
  const [moderators, setModerators] = useState<Moderator[]>([]);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [assigningComplaint, setAssigningComplaint] = useState<Complaint | null>(null);
  const [adminNote, setAdminNote] = useState('');
  
  const [moderatorForm, setModeratorForm] = useState({
    name: '',
    businessName: '',
    email: '',
    phone: '',
    password: ''
  });

  useEffect(() => {
    // Subscribe to real-time complaints
    const unsubscribeComplaints = subscribeToAllComplaints((data) => {
      setComplaints(data);
    });

    // Subscribe to real-time stats
    const unsubscribeStats = subscribeToComplaintStats((data) => {
      setStats(data);
    });

    // Load moderators
    loadModerators();

    return () => {
      unsubscribeComplaints();
      unsubscribeStats();
    };
  }, []);

  const loadModerators = async () => {
    try {
      const mods = await getAllModerators();
      setModerators(mods);
    } catch (error) {
      console.error('Error loading moderators:', error);
    }
  };

  const handleCreateModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createModeratorAccount(
        moderatorForm.name,
        moderatorForm.businessName,
        moderatorForm.email,
        moderatorForm.phone,
        moderatorForm.password
      );
      
      alert('Moderator created successfully!');
      setModeratorForm({ name: '', businessName: '', email: '', phone: '', password: '' });
      setShowModeratorForm(false);
      loadModerators();
    } catch (error: any) {
      alert(error.message || 'Failed to create moderator');
    }
  };

  const handleDeleteModerator = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this moderator?')) {
      try {
        await deleteModerator(id);
        loadModerators();
      } catch (error) {
        alert('Failed to delete moderator');
      }
    }
  };

  const handleDeleteComplaint = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this complaint?')) {
      try {
        await deleteComplaint(id);
      } catch (error) {
        alert('Failed to delete complaint');
      }
    }
  };

  const handleStatusChange = async (id: string, status: Complaint['status']) => {
    try {
      await updateComplaintStatus(id, status);
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const handleAssignComplaint = async (moderator: Moderator) => {
    if (!assigningComplaint) return;
    
    try {
      await assignComplaint(assigningComplaint.id!, moderator.email, moderator.name);
      setShowAssignModal(false);
      setAssigningComplaint(null);
    } catch (error) {
      alert('Failed to assign complaint');
    }
  };

  const handleSaveAdminNote = async () => {
    if (!selectedComplaint) return;
    
    try {
      await updateAdminNote(selectedComplaint.id!, adminNote);
      alert('Note saved successfully');
    } catch (error) {
      alert('Failed to save note');
    }
  };

  const statCards = [
    { label: 'Total', value: stats.total, icon: FileText, color: 'from-blue-500 to-cyan-500' },
    { label: 'Pending', value: stats.pending, icon: Clock, color: 'from-orange-500 to-yellow-500' },
    { label: 'Assigned', value: stats.assigned, icon: Users, color: 'from-blue-500 to-indigo-500' },
    { label: 'Active', value: stats.active, icon: TrendingUp, color: 'from-purple-500 to-pink-500' },
    { label: 'Resolved', value: stats.resolved, icon: CheckCircle, color: 'from-green-500 to-emerald-500' },
    { label: 'Rejected', value: stats.rejected, icon: XCircle, color: 'from-red-500 to-rose-500' }
  ];

  const chartData = [
    { name: 'Pending', value: stats.pending },
    { name: 'Assigned', value: stats.assigned },
    { name: 'Active', value: stats.active },
    { name: 'Resolved', value: stats.resolved },
    { name: 'Rejected', value: stats.rejected }
  ];

  const COLORS = ['#f59e0b', '#3b82f6', '#8b5cf6', '#10b981', '#ef4444'];

  const getStatusBadge = (status: string) => {
    const badges: Record<string, { color: string; label: string }> = {
      pending: { color: 'bg-orange-500/20 text-orange-400 border-orange-500', label: 'Pending' },
      assigned: { color: 'bg-blue-500/20 text-blue-400 border-blue-500', label: 'Assigned' },
      active: { color: 'bg-purple-500/20 text-purple-400 border-purple-500', label: 'Active' },
      resolved: { color: 'bg-green-500/20 text-green-400 border-green-500', label: 'Resolved' },
      rejected: { color: 'bg-red-500/20 text-red-400 border-red-500', label: 'Rejected' }
    };
    
    const badge = badges[status] || badges.pending;
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const badges: Record<string, string> = {
      low: 'bg-green-500/20 text-green-400',
      medium: 'bg-yellow-500/20 text-yellow-400',
      high: 'bg-red-500/20 text-red-400'
    };
    
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${badges[priority] || badges.medium}`}>
        {priority.toUpperCase()}
      </span>
    );
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Admin Dashboard
          </h1>
          <p className="text-slate-400">Manage complaints, moderators, and view analytics</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {statCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="glass-card p-6"
              >
                <div className={`w-12 h-12 mb-4 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`text-3xl font-bold mb-1 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`}>
                  {stat.value}
                </div>
                <div className="text-sm text-slate-400">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-6"
          >
            <h3 className="text-xl font-bold mb-4 text-white">Status Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-card p-6"
          >
            <h3 className="text-xl font-bold mb-4 text-white">Category Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {chartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Moderator Management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 mb-8"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold text-white flex items-center gap-2">
              <Users className="w-6 h-6" />
              Moderator Management
            </h3>
            <button
              onClick={() => setShowModeratorForm(!showModeratorForm)}
              className="glass-button px-4 py-2 flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Add Moderator
            </button>
          </div>

          {/* Create Moderator Form */}
          <AnimatePresence>
            {showModeratorForm && (
              <motion.form
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                onSubmit={handleCreateModerator}
                className="mb-6 p-6 glass-card border-2 border-blue-500/30"
              >
                <h4 className="text-lg font-bold mb-4 text-blue-400">Create New Moderator Account</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Name *</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        value={moderatorForm.name}
                        onChange={(e) => setModeratorForm({ ...moderatorForm, name: e.target.value })}
                        className="glass-input pl-10"
                        placeholder="Full name"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Business Name *</label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        value={moderatorForm.businessName}
                        onChange={(e) => setModeratorForm({ ...moderatorForm, businessName: e.target.value })}
                        className="glass-input pl-10"
                        placeholder="Business/Department"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Email *</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="email"
                        value={moderatorForm.email}
                        onChange={(e) => setModeratorForm({ ...moderatorForm, email: e.target.value })}
                        className="glass-input pl-10"
                        placeholder="email@example.com"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Phone *</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="tel"
                        value={moderatorForm.phone}
                        onChange={(e) => setModeratorForm({ ...moderatorForm, phone: e.target.value })}
                        className="glass-input pl-10"
                        placeholder="Phone number"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Password *</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="password"
                        value={moderatorForm.password}
                        onChange={(e) => setModeratorForm({ ...moderatorForm, password: e.target.value })}
                        className="glass-input pl-10"
                        placeholder="Min 6 characters"
                        minLength={6}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 mt-4">
                  <button type="submit" className="glass-button px-6 py-2">
                    Create Moderator
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModeratorForm(false)}
                    className="glass-card px-6 py-2 hover:bg-red-500/20"
                  >
                    Cancel
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Moderators List */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {moderators.map((mod) => (
              <div key={mod.id} className="glass-card p-4 border border-slate-700">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-bold text-white">{mod.name}</h4>
                    <p className="text-sm text-slate-400">{mod.businessName}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteModerator(mod.id!)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-1 text-sm">
                  <p className="text-slate-300 flex items-center gap-2">
                    <Mail className="w-3 h-3" />
                    {mod.email}
                  </p>
                  <p className="text-slate-300 flex items-center gap-2">
                    <Phone className="w-3 h-3" />
                    {mod.phone}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Complaints Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6"
        >
          <h3 className="text-2xl font-bold mb-6 text-white">All Complaints</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">ID</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Title</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Category</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Status</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Priority</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Assigned To</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {complaints.map((complaint) => (
                  <tr key={complaint.id} className="border-b border-slate-800 hover:bg-white/5">
                    <td className="py-3 px-4 text-sm font-mono text-slate-300">
                      {complaint.id?.substring(0, 8)}...
                    </td>
                    <td className="py-3 px-4 text-sm text-white">{complaint.title}</td>
                    <td className="py-3 px-4 text-sm text-slate-300">{complaint.category}</td>
                    <td className="py-3 px-4 text-sm">{getStatusBadge(complaint.status)}</td>
                    <td className="py-3 px-4 text-sm">{getPriorityBadge(complaint.priority)}</td>
                    <td className="py-3 px-4 text-sm text-slate-300">
                      {complaint.assignedToName || 'Unassigned'}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedComplaint(complaint)}
                          className="text-blue-400 hover:text-blue-300"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setAssigningComplaint(complaint);
                            setShowAssignModal(true);
                          }}
                          className="text-purple-400 hover:text-purple-300"
                          title="Assign"
                        >
                          <Users className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteComplaint(complaint.id!)}
                          className="text-red-400 hover:text-red-300"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Complaint Detail Modal */}
        <AnimatePresence>
          {selectedComplaint && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedComplaint(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="glass-card p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto"
              >
                <h3 className="text-2xl font-bold mb-4 text-white">Complaint Details</h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm text-slate-400 mb-1">Title</h4>
                    <p className="text-white font-medium">{selectedComplaint.title}</p>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Name</h4>
                      <p className="text-white">{selectedComplaint.name}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Email</h4>
                      <p className="text-white">{selectedComplaint.email}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Phone</h4>
                      <p className="text-white">{selectedComplaint.phone}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Employee ID</h4>
                      <p className="text-white">{selectedComplaint.employeeId}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Department</h4>
                      <p className="text-white">{selectedComplaint.department}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Designation</h4>
                      <p className="text-white">{selectedComplaint.designation}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm text-slate-400 mb-1">Description</h4>
                    <p className="text-white">{selectedComplaint.description}</p>
                  </div>

                  {selectedComplaint.imageUrl && (
                    <div>
                      <h4 className="text-sm text-slate-400 mb-2">Attached Image</h4>
                      <img 
                        src={selectedComplaint.imageUrl} 
                        alt="Complaint" 
                        className="max-w-full rounded-lg"
                      />
                    </div>
                  )}

                  <div>
                    <h4 className="text-sm text-slate-400 mb-2">Status</h4>
                    <select
                      value={selectedComplaint.status}
                      onChange={(e) => handleStatusChange(selectedComplaint.id!, e.target.value as any)}
                      className="glass-input"
                    >
                      <option value="pending">Pending</option>
                      <option value="assigned">Assigned</option>
                      <option value="active">Active</option>
                      <option value="resolved">Resolved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>

                  <div>
                    <h4 className="text-sm text-slate-400 mb-2">Admin Note (for Moderator)</h4>
                    <textarea
                      value={adminNote || selectedComplaint.adminNote || ''}
                      onChange={(e) => setAdminNote(e.target.value)}
                      className="glass-input resize-none"
                      rows={3}
                      placeholder="Leave a note for the moderator..."
                    />
                    <button
                      onClick={handleSaveAdminNote}
                      className="glass-button px-4 py-2 mt-2"
                    >
                      Save Note
                    </button>
                  </div>

                  {selectedComplaint.moderatorNote && (
                    <div>
                      <h4 className="text-sm text-slate-400 mb-2">Moderator Note</h4>
                      <div className="glass-card p-4 bg-purple-500/10 border border-purple-500/30">
                        <p className="text-white">{selectedComplaint.moderatorNote}</p>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => setSelectedComplaint(null)}
                    className="w-full glass-card py-3 hover:bg-white/10"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Assign Modal */}
        <AnimatePresence>
          {showAssignModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowAssignModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="glass-card p-6 max-w-md w-full"
              >
                <h3 className="text-2xl font-bold mb-4 text-white">Assign to Moderator</h3>
                <div className="space-y-3">
                  {moderators.map((mod) => (
                    <button
                      key={mod.id}
                      onClick={() => handleAssignComplaint(mod)}
                      className="w-full glass-card p-4 hover:bg-white/10 text-left"
                    >
                      <p className="font-bold text-white">{mod.name}</p>
                      <p className="text-sm text-slate-400">{mod.email}</p>
                      <p className="text-sm text-slate-400">{mod.businessName}</p>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setShowAssignModal(false)}
                  className="w-full mt-4 glass-card py-3 hover:bg-red-500/20"
                >
                  Cancel
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Dashboard;
