import { useState, useEffect } from 'react';

interface Complaint {
  id: string;
  category: string;
  description: string;
  status: 'pending' | 'in-progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  files: string[];
}

export default function Cases() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'in-progress' | 'resolved' | 'closed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('complaints');
    if (stored) {
      setComplaints(JSON.parse(stored));
    }
  }, []);

  const updateComplaintStatus = (id: string, newStatus: Complaint['status']) => {
    const updated = complaints.map(c => 
      c.id === id ? { ...c, status: newStatus } : c
    );
    setComplaints(updated);
    localStorage.setItem('complaints', JSON.stringify(updated));
    if (selectedComplaint?.id === id) {
      setSelectedComplaint({ ...selectedComplaint, status: newStatus });
    }
  };

  const updateComplaintPriority = (id: string, newPriority: Complaint['priority']) => {
    const updated = complaints.map(c => 
      c.id === id ? { ...c, priority: newPriority } : c
    );
    setComplaints(updated);
    localStorage.setItem('complaints', JSON.stringify(updated));
    if (selectedComplaint?.id === id) {
      setSelectedComplaint({ ...selectedComplaint, priority: newPriority });
    }
  };

  const deleteComplaint = (id: string) => {
    const updated = complaints.filter(c => c.id !== id);
    setComplaints(updated);
    localStorage.setItem('complaints', JSON.stringify(updated));
    if (selectedComplaint?.id === id) {
      setSelectedComplaint(null);
    }
  };

  const filteredComplaints = complaints
    .filter(c => filter === 'all' || c.status === filter)
    .filter(c => 
      c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.id.includes(searchQuery)
    );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400 bg-yellow-400/10';
      case 'in-progress': return 'text-blue-400 bg-blue-400/10';
      case 'resolved': return 'text-green-400 bg-green-400/10';
      case 'closed': return 'text-gray-400 bg-gray-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-orange-400';
      case 'low': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold font-headline tracking-tighter text-on-surface mb-4">
          All Cases
        </h1>
        <p className="text-on-surface-variant text-lg">
          Manage and track all complaint cases with advanced filtering.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)] mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant">
              search
            </span>
            <input
              type="text"
              placeholder="Search by ID, category, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-surface-container-low border-0 rounded-xl py-3 pl-12 pr-4 text-on-surface placeholder:text-on-surface-variant/50 focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 flex-wrap">
            {['all', 'pending', 'in-progress', 'resolved', 'closed'].map((status) => (
              <button
                key={status}
                onClick={() => setFilter(status as typeof filter)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                  filter === status
                    ? 'bg-primary text-on-primary-container'
                    : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container'
                }`}
              >
                {status === 'all' ? 'All' : status.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                {status !== 'all' && (
                  <span className="ml-2 opacity-70">
                    ({complaints.filter(c => c.status === status).length})
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cases Grid */}
      {filteredComplaints.length === 0 ? (
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-12 border-t border-l border-white/10 text-center">
          <span className="material-symbols-outlined text-6xl text-on-surface-variant/30 mb-4">
            inbox
          </span>
          <p className="text-on-surface-variant text-lg">No cases found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Cases List */}
          <div className="space-y-4">
            {filteredComplaints.map((complaint) => (
              <div
                key={complaint.id}
                onClick={() => setSelectedComplaint(complaint)}
                className={`bg-surface-bright/60 backdrop-blur-[24px] rounded-xl p-6 border-t border-l border-white/10 cursor-pointer transition-all hover:scale-[1.02] ${
                  selectedComplaint?.id === complaint.id ? 'ring-2 ring-primary' : ''
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${getStatusColor(complaint.status)}`}>
                      {complaint.status}
                    </span>
                    <span className="text-on-surface-variant text-sm">#{complaint.id}</span>
                  </div>
                  <span className={`material-symbols-outlined ${getPriorityColor(complaint.priority)}`} style={{ fontVariationSettings: "'FILL' 1" }}>
                    flag
                  </span>
                </div>
                
                <h3 className="text-on-surface font-bold mb-2 capitalize text-lg">
                  {complaint.category.replace('-', ' ')}
                </h3>
                
                <p className="text-on-surface-variant text-sm line-clamp-2 mb-3">
                  {complaint.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-on-surface-variant">
                  <span className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">calendar_today</span>
                    {new Date(complaint.createdAt).toLocaleDateString()}
                  </span>
                  {complaint.files.length > 0 && (
                    <span className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">attach_file</span>
                      {complaint.files.length} file(s)
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Case Details Panel */}
          <div className="lg:sticky lg:top-24 lg:h-fit">
            {selectedComplaint ? (
              <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-on-surface mb-2 capitalize">
                      {selectedComplaint.category.replace('-', ' ')}
                    </h2>
                    <p className="text-on-surface-variant text-sm">Case #{selectedComplaint.id}</p>
                  </div>
                  <button
                    onClick={() => setSelectedComplaint(null)}
                    className="text-on-surface-variant hover:text-on-surface transition-colors"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                {/* Status */}
                <div className="mb-6">
                  <label className="text-on-surface-variant text-sm font-medium mb-2 block">Status</label>
                  <select
                    value={selectedComplaint.status}
                    onChange={(e) => updateComplaintStatus(selectedComplaint.id, e.target.value as Complaint['status'])}
                    className="w-full bg-surface-container-low border-0 rounded-lg py-2 px-3 text-on-surface focus:ring-2 focus:ring-primary"
                  >
                    <option value="pending">Pending</option>
                    <option value="in-progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                    <option value="closed">Closed</option>
                  </select>
                </div>

                {/* Priority */}
                <div className="mb-6">
                  <label className="text-on-surface-variant text-sm font-medium mb-2 block">Priority</label>
                  <select
                    value={selectedComplaint.priority}
                    onChange={(e) => updateComplaintPriority(selectedComplaint.id, e.target.value as Complaint['priority'])}
                    className="w-full bg-surface-container-low border-0 rounded-lg py-2 px-3 text-on-surface focus:ring-2 focus:ring-primary"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <label className="text-on-surface-variant text-sm font-medium mb-2 block">Description</label>
                  <div className="bg-surface-container-low rounded-lg p-4">
                    <p className="text-on-surface text-sm leading-relaxed">
                      {selectedComplaint.description}
                    </p>
                  </div>
                </div>

                {/* Attachments */}
                {selectedComplaint.files.length > 0 && (
                  <div className="mb-6">
                    <label className="text-on-surface-variant text-sm font-medium mb-2 block">Attachments</label>
                    <div className="space-y-2">
                      {selectedComplaint.files.map((file, index) => (
                        <div key={index} className="bg-surface-container-low rounded-lg p-3 flex items-center gap-3">
                          <span className="material-symbols-outlined text-primary">attach_file</span>
                          <span className="text-on-surface text-sm flex-1">{file}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Created Date */}
                <div className="mb-6">
                  <label className="text-on-surface-variant text-sm font-medium mb-2 block">Created</label>
                  <div className="bg-surface-container-low rounded-lg p-3 flex items-center gap-3">
                    <span className="material-symbols-outlined text-secondary">calendar_today</span>
                    <span className="text-on-surface text-sm">
                      {new Date(selectedComplaint.createdAt).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button className="flex-1 bg-primary hover:bg-primary-container text-on-primary-container font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2">
                    <span className="material-symbols-outlined">edit</span>
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      if (confirm('Are you sure you want to delete this complaint?')) {
                        deleteComplaint(selectedComplaint.id);
                      }
                    }}
                    className="flex-1 bg-error/20 hover:bg-error/30 text-error font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <span className="material-symbols-outlined">delete</span>
                    Delete
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-12 border-t border-l border-white/10 text-center">
                <span className="material-symbols-outlined text-6xl text-on-surface-variant/30 mb-4">
                  description
                </span>
                <p className="text-on-surface-variant">Select a case to view details</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
