import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FileText, Search, Shield, TrendingUp, Clock, CheckCircle, XCircle, AlertCircle, Users } from 'lucide-react';
import { subscribeToComplaintStats, ComplaintStats } from '../services/complaint.service';

const Home = () => {
  const [stats, setStats] = useState<ComplaintStats>({
    total: 0,
    pending: 0,
    assigned: 0,
    active: 0,
    resolved: 0,
    rejected: 0
  });

  useEffect(() => {
    const unsubscribe = subscribeToComplaintStats((newStats) => {
      setStats(newStats);
    });

    return () => unsubscribe();
  }, []);

  const statCards = [
    { 
      label: 'Total Complaints', 
      value: stats.total, 
      icon: FileText, 
      gradient: 'from-blue-500 to-cyan-500',
      bgGradient: 'from-blue-500/10 to-cyan-500/10'
    },
    { 
      label: 'Pending', 
      value: stats.pending, 
      icon: Clock, 
      gradient: 'from-orange-500 to-yellow-500',
      bgGradient: 'from-orange-500/10 to-yellow-500/10'
    },
    { 
      label: 'Assigned', 
      value: stats.assigned, 
      icon: Users, 
      gradient: 'from-blue-500 to-indigo-500',
      bgGradient: 'from-blue-500/10 to-indigo-500/10'
    },
    { 
      label: 'Active', 
      value: stats.active, 
      icon: TrendingUp, 
      gradient: 'from-purple-500 to-pink-500',
      bgGradient: 'from-purple-500/10 to-pink-500/10'
    },
    { 
      label: 'Resolved', 
      value: stats.resolved, 
      icon: CheckCircle, 
      gradient: 'from-green-500 to-emerald-500',
      bgGradient: 'from-green-500/10 to-emerald-500/10'
    },
    { 
      label: 'Rejected', 
      value: stats.rejected, 
      icon: XCircle, 
      gradient: 'from-red-500 to-rose-500',
      bgGradient: 'from-red-500/10 to-rose-500/10'
    }
  ];

  const features = [
    {
      icon: FileText,
      title: 'Easy Submission',
      description: 'Submit your IT complaints with detailed information and attachments',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Search,
      title: 'Track Status',
      description: 'Track your complaint status in real-time with your unique ID',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your data is encrypted and handled with utmost security',
      gradient: 'from-green-500 to-emerald-500'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-24 sm:pt-32 pb-12 sm:pb-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6 sm:space-y-8"
          >
            <h1 
              className="font-bold leading-tight text-white"
              style={{ fontSize: 'clamp(2rem, 8vw, 4rem)' }}
            >
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent block">
                SAIL-MIOM
              </span>
              <span className="block mt-2 text-2xl sm:text-3xl md:text-4xl">
                IT Complaint
              </span>
              <span className="block text-2xl sm:text-3xl md:text-4xl">
                Management System
              </span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-slate-300 max-w-3xl mx-auto px-4 leading-relaxed">
              Efficiently manage and track your IT complaints with our advanced system. 
              Get real-time updates and quick resolutions for all your technical issues.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4 max-w-md sm:max-w-none mx-auto">
              <Link to="/file-complaint" className="w-full sm:w-auto">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="glass-button w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-bold flex items-center justify-center gap-2 text-white min-h-[48px] rounded-xl"
                >
                  <FileText className="w-5 h-5" />
                  File a Complaint
                </motion.button>
              </Link>
              <Link to="/track-complaint" className="w-full sm:w-auto">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="glass-card w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-bold flex items-center justify-center gap-2 text-white min-h-[48px] rounded-xl"
                >
                  <Search className="w-5 h-5" />
                  Track Complaint
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Live Statistics Section */}
      <section className="py-8 sm:py-12 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-center mb-8 sm:mb-12 px-4"
          >
            <h2 
              className="font-bold mb-3 sm:mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
              style={{ fontSize: 'clamp(1.5rem, 5vw, 2.25rem)' }}
            >
              Live Complaint Statistics
            </h2>
            <p className="text-slate-300 text-sm sm:text-base md:text-lg leading-relaxed">
              Real-time overview of all complaints in the system
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {statCards.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.03, y: -3 }}
                  className="relative group"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.bgGradient} rounded-2xl blur-xl opacity-50 group-hover:opacity-100 transition-opacity`} />
                  <div className="relative glass-card p-4 sm:p-6 text-center h-full flex flex-col justify-center">
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center`}>
                      <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                    <div className={`text-2xl sm:text-3xl font-bold mb-1 sm:mb-2 bg-gradient-to-br ${stat.gradient} bg-clip-text text-transparent`}>
                      {stat.value}
                    </div>
                    <div className="text-xs sm:text-sm text-slate-300 font-medium leading-tight">
                      {stat.label}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8 sm:mb-12 px-4"
          >
            <h2 
              className="font-bold mb-3 sm:mb-4 text-white"
              style={{ fontSize: 'clamp(1.5rem, 5vw, 2.25rem)' }}
            >
              Why Choose Our System?
            </h2>
            <p className="text-slate-300 text-sm sm:text-base md:text-lg leading-relaxed">
              Streamlined complaint management with powerful features
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="relative group"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} rounded-2xl blur-xl opacity-20 group-hover:opacity-40 transition-opacity`} />
                  <div className="relative glass-card p-6 sm:p-8 text-center h-full">
                    <div className={`w-14 h-14 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center`}>
                      <Icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-white">{feature.title}</h3>
                    <p className="text-slate-300 text-sm sm:text-base leading-relaxed">{feature.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12 sm:py-20 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8 sm:mb-12 px-4"
          >
            <h2 
              className="font-bold mb-3 sm:mb-4 text-white"
              style={{ fontSize: 'clamp(1.5rem, 5vw, 2.25rem)' }}
            >
              How It Works
            </h2>
            <p className="text-slate-300 text-sm sm:text-base md:text-lg leading-relaxed">
              Simple steps to get your issues resolved
            </p>
          </motion.div>

          <div className="space-y-4 sm:space-y-6">
            {[
              { step: 1, title: 'File Complaint', description: 'Fill out the complaint form with detailed information and attach relevant images' },
              { step: 2, title: 'Get Tracking ID', description: 'Receive a unique tracking ID to monitor your complaint status' },
              { step: 3, title: 'Review & Assignment', description: 'Our team reviews and assigns your complaint to the appropriate moderator' },
              { step: 4, title: 'Resolution', description: 'Track progress and receive updates until your issue is resolved' }
            ].map((item, index) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 * index }}
                className="glass-card p-4 sm:p-6 flex items-start gap-3 sm:gap-4 hover:scale-[1.02] transition-transform"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 text-lg sm:text-xl font-bold text-white">
                  {item.step}
                </div>
                <div className="flex-1">
                  <h3 className="text-base sm:text-lg md:text-xl font-bold mb-1 sm:mb-2 text-white">{item.title}</h3>
                  <p className="text-slate-300 text-sm sm:text-base leading-relaxed">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-20 px-4 sm:px-6 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto glass-card p-8 sm:p-12 text-center relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-48 h-48 sm:w-64 sm:h-64 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 sm:w-64 sm:h-64 bg-gradient-to-tr from-pink-500/20 to-purple-500/20 rounded-full blur-3xl" />
          
          <div className="relative z-10">
            <AlertCircle className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6 text-blue-400" />
            <h2 
              className="font-bold mb-3 sm:mb-4 text-white"
              style={{ fontSize: 'clamp(1.5rem, 5vw, 2.25rem)' }}
            >
              Need Help with IT Issues?
            </h2>
            <p className="text-slate-300 text-sm sm:text-base md:text-lg mb-6 sm:mb-8 leading-relaxed px-4">
              Don't let technical problems slow you down. File a complaint now and get expert assistance.
            </p>
            <Link to="/file-complaint" className="inline-block w-full sm:w-auto">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="glass-button w-full sm:w-auto px-8 sm:px-10 py-3 sm:py-4 text-base sm:text-lg font-bold text-white min-h-[48px] rounded-xl"
              >
                Get Started
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

export default Home;
