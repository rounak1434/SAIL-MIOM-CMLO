/**
 * ImgBB Image Upload Service
 * Uploads images to ImgBB and returns the URL
 */

const IMGBB_API_KEY = "ee6322c19b03b982de5cb488e29f207c";

export const uploadToImgBB = async (file: File): Promise<string> => {
  try {
    const formData = new FormData();
    formData.append("image", file);

    const response = await fetch(
      `https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`,
      {
        method: "POST",
        body: formData,
      }
    );

    const data = await response.json();

    if (!data.success) {
      throw new Error("Image upload failed");
    }

    return data.data.url;
  } catch (error) {
    console.error("ImgBB Upload Error:", error);
    throw new Error("Failed to upload image");
  }
};
