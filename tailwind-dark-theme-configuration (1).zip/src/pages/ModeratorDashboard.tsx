import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Clock, TrendingUp, CheckCircle, Eye, MessageSquare } from 'lucide-react';
import { 
  subscribeToModeratorComplaints, 
  Complaint,
  updateComplaintStatus,
  updateModeratorNote
} from '../services/complaint.service';
import { useAuth } from '../context/AuthContext';

const ModeratorDashboard = () => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [moderatorNote, setModeratorNote] = useState('');

  useEffect(() => {
    if (!user?.email) return;

    // Subscribe to complaints assigned to this moderator
    const unsubscribe = subscribeToModeratorComplaints(user.email, (data) => {
      setComplaints(data);
    });

    return () => unsubscribe();
  }, [user]);

  const stats = {
    total: complaints.length,
    active: complaints.filter(c => c.status === 'active').length,
    resolved: complaints.filter(c => c.status === 'resolved').length,
    pending: complaints.filter(c => c.status === 'pending' || c.status === 'assigned').length
  };

  const handleStatusChange = async (id: string, status: Complaint['status']) => {
    try {
      await updateComplaintStatus(id, status);
      alert('Status updated successfully');
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const handleSaveNote = async () => {
    if (!selectedComplaint) return;
    
    try {
      await updateModeratorNote(selectedComplaint.id!, moderatorNote);
      alert('Note saved successfully');
    } catch (error) {
      alert('Failed to save note');
    }
  };

  const getStatusBadge = (status: string) => {
    const badges: Record<string, { color: string; label: string }> = {
      pending: { color: 'bg-orange-500/20 text-orange-400 border-orange-500', label: 'Pending' },
      assigned: { color: 'bg-blue-500/20 text-blue-400 border-blue-500', label: 'Assigned' },
      active: { color: 'bg-purple-500/20 text-purple-400 border-purple-500', label: 'Active' },
      resolved: { color: 'bg-green-500/20 text-green-400 border-green-500', label: 'Resolved' },
      rejected: { color: 'bg-red-500/20 text-red-400 border-red-500', label: 'Rejected' }
    };
    
    const badge = badges[status] || badges.pending;
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${badge.color}`}>
        {badge.label}
      </span>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const badges: Record<string, string> = {
      low: 'bg-green-500/20 text-green-400',
      medium: 'bg-yellow-500/20 text-yellow-400',
      high: 'bg-red-500/20 text-red-400'
    };
    
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${badges[priority] || badges.medium}`}>
        {priority.toUpperCase()}
      </span>
    );
  };

  const statCards = [
    { label: 'Total Assigned', value: stats.total, icon: FileText, color: 'from-blue-500 to-cyan-500' },
    { label: 'Pending', value: stats.pending, icon: Clock, color: 'from-orange-500 to-yellow-500' },
    { label: 'Active', value: stats.active, icon: TrendingUp, color: 'from-purple-500 to-pink-500' },
    { label: 'Resolved', value: stats.resolved, icon: CheckCircle, color: 'from-green-500 to-emerald-500' }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Moderator Dashboard
          </h1>
          <p className="text-slate-400">View and manage your assigned complaints</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="glass-card p-6"
              >
                <div className={`w-12 h-12 mb-4 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`text-3xl font-bold mb-1 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`}>
                  {stat.value}
                </div>
                <div className="text-sm text-slate-400">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>

        {/* Complaints List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6"
        >
          <h3 className="text-2xl font-bold mb-6 text-white">Your Assigned Complaints</h3>
          
          {complaints.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 mx-auto mb-4 text-slate-600" />
              <p className="text-slate-400 text-lg">No complaints assigned yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">ID</th>
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">Title</th>
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">Category</th>
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">Status</th>
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">Priority</th>
                    <th className="text-left py-3 px-4 text-slate-400 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {complaints.map((complaint) => (
                    <tr key={complaint.id} className="border-b border-slate-800 hover:bg-white/5">
                      <td className="py-3 px-4 text-sm font-mono text-slate-300">
                        {complaint.id?.substring(0, 8)}...
                      </td>
                      <td className="py-3 px-4 text-sm text-white">{complaint.title}</td>
                      <td className="py-3 px-4 text-sm text-slate-300">{complaint.category}</td>
                      <td className="py-3 px-4 text-sm">{getStatusBadge(complaint.status)}</td>
                      <td className="py-3 px-4 text-sm">{getPriorityBadge(complaint.priority)}</td>
                      <td className="py-3 px-4 text-sm">
                        <button
                          onClick={() => {
                            setSelectedComplaint(complaint);
                            setModeratorNote(complaint.moderatorNote || '');
                          }}
                          className="text-blue-400 hover:text-blue-300 flex items-center gap-1"
                        >
                          <Eye className="w-4 h-4" />
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>

        {/* Complaint Detail Modal */}
        <AnimatePresence>
          {selectedComplaint && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedComplaint(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="glass-card p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto"
              >
                <h3 className="text-2xl font-bold mb-4 text-white flex items-center gap-2">
                  <FileText className="w-6 h-6" />
                  Complaint Details
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm text-slate-400 mb-1">Title</h4>
                    <p className="text-white font-medium">{selectedComplaint.title}</p>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Name</h4>
                      <p className="text-white">{selectedComplaint.name}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Email</h4>
                      <p className="text-white">{selectedComplaint.email}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Phone</h4>
                      <p className="text-white">{selectedComplaint.phone}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Employee ID</h4>
                      <p className="text-white">{selectedComplaint.employeeId}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Department</h4>
                      <p className="text-white">{selectedComplaint.department}</p>
                    </div>
                    <div>
                      <h4 className="text-sm text-slate-400 mb-1">Designation</h4>
                      <p className="text-white">{selectedComplaint.designation}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm text-slate-400 mb-1">Description</h4>
                    <p className="text-white">{selectedComplaint.description}</p>
                  </div>

                  {selectedComplaint.imageUrl && (
                    <div>
                      <h4 className="text-sm text-slate-400 mb-2">Attached Image</h4>
                      <img 
                        src={selectedComplaint.imageUrl} 
                        alt="Complaint" 
                        className="max-w-full rounded-lg"
                      />
                    </div>
                  )}

                  {selectedComplaint.adminNote && (
                    <div>
                      <h4 className="text-sm text-slate-400 mb-2">Admin Note</h4>
                      <div className="glass-card p-4 bg-blue-500/10 border border-blue-500/30">
                        <p className="text-white">{selectedComplaint.adminNote}</p>
                      </div>
                    </div>
                  )}

                  <div>
                    <h4 className="text-sm text-slate-400 mb-2">Update Status</h4>
                    <select
                      value={selectedComplaint.status}
                      onChange={(e) => handleStatusChange(selectedComplaint.id!, e.target.value as any)}
                      className="glass-input"
                    >
                      <option value="assigned">Assigned</option>
                      <option value="active">Active</option>
                      <option value="resolved">Resolved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>

                  <div>
                    <h4 className="text-sm text-slate-400 mb-2 flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" />
                      Your Note (for Admin)
                    </h4>
                    <textarea
                      value={moderatorNote}
                      onChange={(e) => setModeratorNote(e.target.value)}
                      className="glass-input resize-none"
                      rows={4}
                      placeholder="Leave a note for the admin about this complaint..."
                    />
                    <button
                      onClick={handleSaveNote}
                      className="glass-button px-4 py-2 mt-2"
                    >
                      Save Note
                    </button>
                  </div>

                  <button
                    onClick={() => setSelectedComplaint(null)}
                    className="w-full glass-card py-3 hover:bg-white/10"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ModeratorDashboard;
