import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { collection, query, where, getDocs, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { createModerator } from '../services/auth.service';
import { useAuth } from '../contexts/AuthContext';
import { User, Mail, Phone, Building2, Lock, Trash2, Key, X, UserPlus } from 'lucide-react';

interface ModeratorData {
  uid: string;
  name: string;
  businessName: string;
  email: string;
  phone: string;
  createdAt: string;
}

export const ModeratorManagement = () => {
  const { userRole } = useAuth();
  const [moderators, setModerators] = useState<ModeratorData[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [selectedModerator, setSelectedModerator] = useState<ModeratorData | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    email: '',
    phone: '',
    password: ''
  });
  const [newPassword, setNewPassword] = useState('');
  const [showPasswordCreate, setShowPasswordCreate] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchModerators();
  }, []);

  const fetchModerators = async () => {
    try {
      const q = query(collection(db, 'users'), where('role', '==', 'moderator'));
      const snapshot = await getDocs(q);
      const mods: ModeratorData[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        mods.push({
          uid: doc.id,
          name: data.name || '',
          businessName: data.businessName || '',
          email: data.email || '',
          phone: data.phone || '',
          createdAt: data.createdAt || new Date().toISOString()
        });
      });
      setModerators(mods);
    } catch (err) {
      console.error('Failed to fetch moderators:', err);
    }
  };

  const handleCreateModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validation
    if (!formData.name || !formData.businessName || !formData.email || !formData.phone || !formData.password) {
      setError('Please fill all fields');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      await createModerator(
        formData.email,
        formData.password,
        formData.name,
        formData.businessName,
        formData.phone
      );
      
      setSuccess('Moderator account created successfully!');
      await fetchModerators();
      setShowCreateForm(false);
      setFormData({ name: '', businessName: '', email: '', phone: '', password: '' });
      
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to create moderator');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteModerator = async (uid: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete moderator "${name}"? This action cannot be undone.`)) {
      try {
        await deleteDoc(doc(db, 'users', uid));
        setSuccess('Moderator deleted successfully!');
        await fetchModerators();
        setTimeout(() => setSuccess(''), 3000);
      } catch (err) {
        setError('Failed to delete moderator');
        console.error('Failed to delete moderator:', err);
      }
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!newPassword || newPassword.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      // Note: Firebase doesn't allow changing passwords from admin side directly
      // You would need Firebase Admin SDK or Cloud Functions for this
      // For now, we'll update a field in Firestore to indicate password needs to be changed
      if (selectedModerator) {
        await updateDoc(doc(db, 'users', selectedModerator.uid), {
          passwordChangeRequired: true,
          tempPassword: newPassword // In production, use Cloud Function to actually change password
        });
        
        setSuccess('Password change request sent! Moderator will need to update on next login.');
        setShowChangePassword(false);
        setNewPassword('');
        setSelectedModerator(null);
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err: any) {
      setError('Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  if (userRole?.role !== 'admin') {
    return (
      <div className="min-h-screen pt-32 flex items-center justify-center">
        <div className="glass-card p-8 text-center">
          <p className="text-red-400 text-lg">⛔ Access Denied. Admin only.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-4xl font-bold font-headline bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
              Moderator Management
            </h1>
            <p className="text-gray-400">Create and manage moderator accounts</p>
          </motion.div>

          <motion.button
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="glass-button px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500/20 to-purple-500/20 hover:from-blue-500/30 hover:to-purple-500/30 border border-blue-500/30 text-white font-semibold flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          >
            {showCreateForm ? (
              <>
                <X className="w-5 h-5" />
                Cancel
              </>
            ) : (
              <>
                <UserPlus className="w-5 h-5" />
                Create Moderator
              </>
            )}
          </motion.button>
        </div>

        {/* Success/Error Messages */}
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 bg-green-500/10 border border-green-500/30 text-green-400 px-6 py-4 rounded-xl backdrop-blur-sm"
          >
            ✅ {success}
          </motion.div>
        )}

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 bg-red-500/10 border border-red-500/30 text-red-400 px-6 py-4 rounded-xl backdrop-blur-sm"
          >
            ❌ {error}
          </motion.div>
        )}

        {/* Create Form */}
        {showCreateForm && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-8 mb-8 border border-blue-500/20"
          >
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
              <UserPlus className="w-6 h-6 text-blue-400" />
              Create New Moderator Account
            </h2>

            <form onSubmit={handleCreateModerator} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                    placeholder="Enter full name"
                    required
                  />
                </div>

                {/* Business Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    Business Name *
                  </label>
                  <input
                    type="text"
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                    className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                    placeholder="Enter business/department name"
                    required
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                    placeholder="moderator@example.com"
                    required
                  />
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                    placeholder="+91 98765 43210"
                    required
                  />
                </div>

                {/* Password */}
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Password * (minimum 6 characters)
                  </label>
                  <div className="relative">
                    <input
                      type={showPasswordCreate ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 pr-12 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all outline-none"
                      placeholder="Enter secure password"
                      required
                      minLength={6}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswordCreate(!showPasswordCreate)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                    >
                      {showPasswordCreate ? (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full glass-button py-4 rounded-xl bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-bold text-lg transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/30"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Creating...
                  </span>
                ) : (
                  'Create Moderator Account'
                )}
              </button>
            </form>
          </motion.div>
        )}

        {/* Change Password Modal */}
        {showChangePassword && selectedModerator && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowChangePassword(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-card p-8 max-w-md w-full border border-purple-500/30"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Key className="w-6 h-6 text-purple-400" />
                  Change Password
                </h3>
                <button
                  onClick={() => setShowChangePassword(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <p className="text-gray-400 mb-6">
                Changing password for: <span className="text-white font-semibold">{selectedModerator.name}</span>
              </p>

              <form onSubmit={handleChangePassword} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    New Password (minimum 6 characters)
                  </label>
                  <div className="relative">
                    <input
                      type={showPasswordChange ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="glass-input w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 pr-12 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all outline-none"
                      placeholder="Enter new password"
                      required
                      minLength={6}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPasswordChange(!showPasswordChange)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                    >
                      {showPasswordChange ? (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowChangePassword(false)}
                    className="flex-1 px-4 py-3 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 font-semibold transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 px-4 py-3 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold transition-all disabled:opacity-50"
                  >
                    {loading ? 'Changing...' : 'Change Password'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}

        {/* Moderators List */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white mb-6">
            Moderator Accounts ({moderators.length})
          </h2>

          {moderators.length === 0 ? (
            <div className="glass-card p-12 text-center">
              <UserPlus className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">No moderators created yet</p>
              <p className="text-gray-500 mt-2">Click "Create Moderator" to add your first moderator</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {moderators.map((mod, index) => (
                <motion.div
                  key={mod.uid}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="glass-card p-6 hover:border-blue-500/30 transition-all group"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 grid md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                          <User className="w-3 h-3" />
                          Name
                        </p>
                        <p className="text-white font-semibold">{mod.name}</p>
                      </div>

                      <div>
                        <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          Business
                        </p>
                        <p className="text-gray-300">{mod.businessName}</p>
                      </div>

                      <div>
                        <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          Email
                        </p>
                        <p className="text-gray-300 truncate">{mod.email}</p>
                      </div>

                      <div>
                        <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          Phone
                        </p>
                        <p className="text-gray-300">{mod.phone}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 ml-4">
                      <button
                        onClick={() => {
                          setSelectedModerator(mod);
                          setShowChangePassword(true);
                        }}
                        className="p-2 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 hover:text-purple-300 transition-all group-hover:scale-110"
                        title="Change Password"
                      >
                        <Key className="w-5 h-5" />
                      </button>

                      <button
                        onClick={() => handleDeleteModerator(mod.uid, mod.name)}
                        className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 transition-all group-hover:scale-110"
                        title="Delete Moderator"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-white/5">
                    <p className="text-xs text-gray-500">
                      Created: {new Date(mod.createdAt).toLocaleDateString()} at {new Date(mod.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ModeratorManagement;
