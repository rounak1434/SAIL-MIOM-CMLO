import { 
  collection, 
  addDoc, 
  deleteDoc, 
  doc, 
  getDocs,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { 
  createUserWithEmailAndPassword,
  updatePassword,
  signOut,
  signInWithEmailAndPassword
} from 'firebase/auth';
import { auth, db } from './firebase';

export interface Moderator {
  id?: string;
  name: string;
  businessName: string;
  email: string;
  phone: string;
  role: 'moderator';
  createdAt: any;
}

// Create moderator account
export const createModeratorAccount = async (
  name: string,
  businessName: string,
  email: string,
  phone: string,
  password: string
): Promise<string> => {
  try {
    // Create new moderator in Firebase Auth
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;
    
    // Create moderator document in Firestore
    await addDoc(collection(db, 'users'), {
      uid,
      name,
      businessName,
      email,
      phone,
      role: 'moderator',
      createdAt: serverTimestamp()
    });
    
    // Sign out the newly created moderator
    await signOut(auth);
    
    // Re-authenticate the admin if there was a current user
    // This is handled by the calling component
    
    return uid;
  } catch (error: any) {
    console.error('Error creating moderator:', error);
    if (error.code === 'auth/email-already-in-use') {
      throw new Error('Email already in use');
    }
    throw error;
  }
};

// Get all moderators
export const getAllModerators = async (): Promise<Moderator[]> => {
  try {
    const q = query(collection(db, 'users'), where('role', '==', 'moderator'));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Moderator));
  } catch (error) {
    console.error('Error getting moderators:', error);
    throw error;
  }
};

// Delete moderator
export const deleteModerator = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'users', id));
    // Note: This only deletes from Firestore
    // Firebase Auth user deletion requires Admin SDK on backend
  } catch (error) {
    console.error('Error deleting moderator:', error);
    throw error;
  }
};

// Change moderator password (requires admin to know moderator's current credentials)
export const changeModeratorPassword = async (
  email: string,
  oldPassword: string,
  newPassword: string
): Promise<void> => {
  try {
    // This is a simplified version
    // In production, this should be done via Admin SDK on backend
    
    // Sign in as moderator
    const userCredential = await signInWithEmailAndPassword(auth, email, oldPassword);
    
    // Update password
    await updatePassword(userCredential.user, newPassword);
    
    // Sign out moderator
    await signOut(auth);
    
    // Admin needs to re-login after this operation
  } catch (error) {
    console.error('Error changing password:', error);
    throw error;
  }
};
