import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where,
  onSnapshot,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './firebase';
import { uploadToImgBB } from './imgbb.service';

export interface Complaint {
  id?: string;
  name: string;
  email: string;
  phone: string;
  employeeId: string;
  department: string;
  designation: string;
  category: 'Computer Complaint' | 'CCTV Complaint' | 'Network Complaint' | 'Others';
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  imageUrl?: string;
  status: 'pending' | 'assigned' | 'active' | 'resolved' | 'rejected';
  assignedTo?: string;
  assignedToName?: string;
  adminNote?: string;
  moderatorNote?: string;
  createdAt: any;
  updatedAt?: any;
}

export interface ComplaintStats {
  total: number;
  pending: number;
  assigned: number;
  active: number;
  resolved: number;
  rejected: number;
}

// Upload image to ImgBB (replaces Firebase Storage)
export const uploadComplaintImage = async (file: File): Promise<string> => {
  try {
    const imageUrl = await uploadToImgBB(file);
    return imageUrl;
  } catch (error) {
    console.error('Error uploading image:', error);
    throw new Error('Failed to upload image');
  }
};

// Create a new complaint
export const createComplaint = async (
  complaintData: Omit<Complaint, 'id' | 'createdAt' | 'status' | 'assignedTo'>
): Promise<{ id: string; complaintId: string }> => {
  try {
    const docRef = await addDoc(collection(db, 'complaints'), {
      ...complaintData,
      status: 'pending',
      assignedTo: null,
      adminNote: '',
      moderatorNote: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    
    return { id: docRef.id, complaintId: docRef.id };
  } catch (error) {
    console.error('Error creating complaint:', error);
    throw error;
  }
};

// Get all complaints (Admin)
export const getAllComplaints = async (): Promise<Complaint[]> => {
  try {
    const querySnapshot = await getDocs(
      query(collection(db, 'complaints'), orderBy('createdAt', 'desc'))
    );
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Complaint));
  } catch (error) {
    console.error('Error getting complaints:', error);
    throw error;
  }
};

// Get complaints assigned to moderator
export const getModeratorComplaints = async (moderatorEmail: string): Promise<Complaint[]> => {
  try {
    const q = query(
      collection(db, 'complaints'),
      where('assignedTo', '==', moderatorEmail),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Complaint));
  } catch (error) {
    console.error('Error getting moderator complaints:', error);
    throw error;
  }
};

// Get complaint by ID
export const getComplaintById = async (id: string): Promise<Complaint | null> => {
  try {
    const docRef = doc(db, 'complaints', id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Complaint;
    }
    return null;
  } catch (error) {
    console.error('Error getting complaint:', error);
    throw error;
  }
};

// Update complaint status
export const updateComplaintStatus = async (
  id: string, 
  status: Complaint['status']
): Promise<void> => {
  try {
    const docRef = doc(db, 'complaints', id);
    await updateDoc(docRef, {
      status,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating status:', error);
    throw error;
  }
};

// Assign complaint to moderator
export const assignComplaint = async (
  id: string,
  moderatorEmail: string,
  moderatorName: string
): Promise<void> => {
  try {
    const docRef = doc(db, 'complaints', id);
    await updateDoc(docRef, {
      assignedTo: moderatorEmail,
      assignedToName: moderatorName,
      status: 'assigned',
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error assigning complaint:', error);
    throw error;
  }
};

// Update admin note
export const updateAdminNote = async (id: string, note: string): Promise<void> => {
  try {
    const docRef = doc(db, 'complaints', id);
    await updateDoc(docRef, {
      adminNote: note,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating admin note:', error);
    throw error;
  }
};

// Update moderator note
export const updateModeratorNote = async (id: string, note: string): Promise<void> => {
  try {
    const docRef = doc(db, 'complaints', id);
    await updateDoc(docRef, {
      moderatorNote: note,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating moderator note:', error);
    throw error;
  }
};

// Delete complaint (Admin only)
export const deleteComplaint = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'complaints', id));
  } catch (error) {
    console.error('Error deleting complaint:', error);
    throw error;
  }
};

// Real-time complaint statistics
export const subscribeToComplaintStats = (
  callback: (stats: ComplaintStats) => void
): (() => void) => {
  const q = query(collection(db, 'complaints'));
  
  const unsubscribe = onSnapshot(q, (snapshot) => {
    const complaints = snapshot.docs.map(doc => doc.data() as Complaint);
    
    const stats: ComplaintStats = {
      total: complaints.length,
      pending: complaints.filter(c => c.status === 'pending').length,
      assigned: complaints.filter(c => c.status === 'assigned').length,
      active: complaints.filter(c => c.status === 'active').length,
      resolved: complaints.filter(c => c.status === 'resolved').length,
      rejected: complaints.filter(c => c.status === 'rejected').length
    };
    
    callback(stats);
  });
  
  return unsubscribe;
};

// Real-time all complaints listener
export const subscribeToAllComplaints = (
  callback: (complaints: Complaint[]) => void
): (() => void) => {
  const q = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
  
  const unsubscribe = onSnapshot(q, (snapshot) => {
    const complaints = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Complaint));
    callback(complaints);
  });
  
  return unsubscribe;
};

// Real-time moderator complaints listener
export const subscribeToModeratorComplaints = (
  moderatorEmail: string,
  callback: (complaints: Complaint[]) => void
): (() => void) => {
  const q = query(
    collection(db, 'complaints'),
    where('assignedTo', '==', moderatorEmail),
    orderBy('createdAt', 'desc')
  );
  
  const unsubscribe = onSnapshot(q, (snapshot) => {
    const complaints = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Complaint));
    callback(complaints);
  });
  
  return unsubscribe;
};
