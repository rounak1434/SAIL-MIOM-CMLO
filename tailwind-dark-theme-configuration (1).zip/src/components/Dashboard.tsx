import { useState, useEffect } from 'react';

interface DashboardProps {
  onNavigate: (page: 'dashboard' | 'analytics' | 'cases' | 'submit') => void;
}

interface Complaint {
  id: string;
  category: string;
  description: string;
  status: 'pending' | 'in-progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  files: string[];
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('complaints');
    if (stored) {
      setComplaints(JSON.parse(stored));
    }
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400 bg-yellow-400/10';
      case 'in-progress': return 'text-blue-400 bg-blue-400/10';
      case 'resolved': return 'text-green-400 bg-green-400/10';
      case 'closed': return 'text-gray-400 bg-gray-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-orange-400';
      case 'low': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'pending').length,
    inProgress: complaints.filter(c => c.status === 'in-progress').length,
    resolved: complaints.filter(c => c.status === 'resolved').length,
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold font-headline tracking-tighter text-on-surface mb-4">
          Dashboard Overview
        </h1>
        <p className="text-on-surface-variant text-lg">
          Monitor and manage all complaints in one centralized hub.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {/* Total Complaints */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <span className="material-symbols-outlined text-primary text-3xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              description
            </span>
            <span className="text-3xl font-bold text-on-surface">{stats.total}</span>
          </div>
          <h3 className="text-on-surface-variant text-sm font-medium">Total Complaints</h3>
        </div>

        {/* Pending */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <span className="material-symbols-outlined text-yellow-400 text-3xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              schedule
            </span>
            <span className="text-3xl font-bold text-on-surface">{stats.pending}</span>
          </div>
          <h3 className="text-on-surface-variant text-sm font-medium">Pending Review</h3>
        </div>

        {/* In Progress */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <span className="material-symbols-outlined text-blue-400 text-3xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              pending
            </span>
            <span className="text-3xl font-bold text-on-surface">{stats.inProgress}</span>
          </div>
          <h3 className="text-on-surface-variant text-sm font-medium">In Progress</h3>
        </div>

        {/* Resolved */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <span className="material-symbols-outlined text-green-400 text-3xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              check_circle
            </span>
            <span className="text-3xl font-bold text-on-surface">{stats.resolved}</span>
          </div>
          <h3 className="text-on-surface-variant text-sm font-medium">Resolved</h3>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <button
          onClick={() => onNavigate('submit')}
          className="bg-gradient-to-br from-primary to-primary-container rounded-2xl p-6 text-left hover:scale-[1.02] transition-transform shadow-[0_0_20px_rgba(133,173,255,0.2)]"
        >
          <span className="material-symbols-outlined text-4xl text-on-primary-container mb-3">
            add_circle
          </span>
          <h3 className="text-xl font-bold text-on-primary-container mb-2">New Complaint</h3>
          <p className="text-on-primary-container/80 text-sm">Submit a new complaint for review</p>
        </button>

        <button
          onClick={() => onNavigate('analytics')}
          className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 text-left border-t border-l border-white/10 hover:scale-[1.02] transition-transform"
        >
          <span className="material-symbols-outlined text-4xl text-secondary mb-3" style={{ fontVariationSettings: "'FILL' 1" }}>
            analytics
          </span>
          <h3 className="text-xl font-bold text-on-surface mb-2">View Analytics</h3>
          <p className="text-on-surface-variant text-sm">Detailed insights and trends</p>
        </button>

        <button
          onClick={() => onNavigate('cases')}
          className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-6 text-left border-t border-l border-white/10 hover:scale-[1.02] transition-transform"
        >
          <span className="material-symbols-outlined text-4xl text-tertiary mb-3" style={{ fontVariationSettings: "'FILL' 1" }}>
            folder_open
          </span>
          <h3 className="text-xl font-bold text-on-surface mb-2">All Cases</h3>
          <p className="text-on-surface-variant text-sm">Browse all complaint cases</p>
        </button>
      </div>

      {/* Recent Complaints */}
      <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold font-headline text-on-surface">Recent Complaints</h2>
          <button
            onClick={() => onNavigate('cases')}
            className="text-primary hover:text-primary-container transition-colors text-sm font-medium flex items-center gap-1"
          >
            View All
            <span className="material-symbols-outlined text-sm">arrow_forward</span>
          </button>
        </div>

        {complaints.length === 0 ? (
          <div className="text-center py-12">
            <span className="material-symbols-outlined text-6xl text-on-surface-variant/30 mb-4">
              inbox
            </span>
            <p className="text-on-surface-variant">No complaints yet. Click "New Complaint" to get started.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {complaints.slice(0, 5).map((complaint) => (
              <div
                key={complaint.id}
                className="bg-surface-container-low rounded-xl p-6 hover:bg-surface-container transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${getStatusColor(complaint.status)}`}>
                        {complaint.status}
                      </span>
                      <span className="text-on-surface-variant text-sm">
                        #{complaint.id}
                      </span>
                    </div>
                    <h3 className="text-on-surface font-semibold mb-2 capitalize">
                      {complaint.category.replace('-', ' ')}
                    </h3>
                    <p className="text-on-surface-variant text-sm line-clamp-2">
                      {complaint.description}
                    </p>
                  </div>
                  <span className={`material-symbols-outlined ${getPriorityColor(complaint.priority)}`}>
                    flag
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-on-surface-variant">
                  <span>{new Date(complaint.createdAt).toLocaleDateString()}</span>
                  {complaint.files.length > 0 && (
                    <span className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">attach_file</span>
                      {complaint.files.length} file(s)
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
