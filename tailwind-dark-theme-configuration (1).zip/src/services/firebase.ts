import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAQ_tlIUBBWhG4aNt5UR5rseZe1A9S3RuU",
  authDomain: "complaint-management-sys-1266f.firebaseapp.com",
  projectId: "complaint-management-sys-1266f",
  storageBucket: "complaint-management-sys-1266f.firebasestorage.app",
  messagingSenderId: "661424164276",
  appId: "1:661424164276:web:b242588d8bc11395ba76e1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services (NO STORAGE - using ImgBB instead)
export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;
