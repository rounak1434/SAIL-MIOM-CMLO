import { useState } from 'react';

export default function ComplaintForm() {
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (category && description) {
      // Store in localStorage for demonstration
      const complaints = JSON.parse(localStorage.getItem('complaints') || '[]');
      const newComplaint = {
        id: Date.now().toString(),
        category,
        description,
        status: 'pending',
        priority: 'medium',
        createdAt: new Date().toISOString(),
        files: files.map(f => f.name)
      };
      complaints.push(newComplaint);
      localStorage.setItem('complaints', JSON.stringify(complaints));
      
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setCategory('');
        setDescription('');
        setFiles([]);
      }, 3000);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-6 max-w-md">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center">
            <span className="material-symbols-outlined text-4xl text-white" style={{ fontVariationSettings: "'FILL' 1" }}>
              check_circle
            </span>
          </div>
          <h2 className="text-3xl font-bold font-headline text-on-surface">Complaint Submitted!</h2>
          <p className="text-on-surface-variant text-lg">
            Your complaint has been received and assigned a case number. Our team will review it within 24-48 hours.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      {/* Header Text */}
      <div className="text-center mb-12 space-y-4 max-w-2xl">
        <h1 className="text-4xl md:text-5xl font-extrabold font-headline tracking-tighter text-on-surface">
          Submit a Complaint
        </h1>
        <p className="text-on-surface-variant text-lg">
          Your voice matters. Provide the details below, and our arbitration team will review your case with full transparency.
        </p>
      </div>

      {/* Centered Glassmorphic Form Card */}
      <div className="w-full max-w-2xl bg-surface-bright/60 backdrop-blur-[24px] saturate-[150%] rounded-[1.5rem] border-t border-l border-white/10 p-8 md:p-12 shadow-[0_20px_40px_rgba(40,0,103,0.08)] relative overflow-hidden">
        {/* Decorative Accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-3xl -z-10"></div>
        
        <form onSubmit={handleSubmit} className="space-y-10">
          {/* Category Section */}
          <div className="space-y-3">
            <label className="font-headline font-bold text-sm tracking-widest uppercase text-primary/80 block">
              Category
            </label>
            <div className="relative">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-transparent border-0 border-b-2 border-surface-container-highest focus:border-primary focus:ring-0 text-on-surface py-3 px-0 font-medium transition-all appearance-none cursor-pointer"
                required
              >
                <option value="" disabled>Select a category...</option>
                <option value="service">Service Quality</option>
                <option value="billing">Billing & Finance</option>
                <option value="technical">Technical Issue</option>
                <option value="product">Product Defect</option>
                <option value="delivery">Delivery & Shipping</option>
                <option value="other">Other Inquiry</option>
              </select>
              <span className="material-symbols-outlined absolute right-0 bottom-3 pointer-events-none text-on-surface-variant">
                expand_more
              </span>
            </div>
          </div>

          {/* Description Section */}
          <div className="space-y-3">
            <label className="font-headline font-bold text-sm tracking-widest uppercase text-primary/80 block">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-transparent border-0 border-b-2 border-surface-container-highest focus:border-primary focus:ring-0 text-on-surface py-3 px-0 font-medium transition-all placeholder:text-on-surface-variant/50 resize-none"
              placeholder="Please describe your complaint in detail..."
              rows={4}
              required
            />
          </div>

          {/* Attachments Section */}
          <div className="space-y-3">
            <label className="font-headline font-bold text-sm tracking-widest uppercase text-primary/80 block">
              Attachments
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Upload Trigger */}
              <div className="md:col-span-2 group">
                <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-outline-variant/30 rounded-xl hover:border-primary/50 hover:bg-white/5 transition-all cursor-pointer relative overflow-hidden">
                  <span className="material-symbols-outlined text-4xl text-on-surface-variant mb-3 group-hover:text-primary transition-colors">
                    cloud_upload
                  </span>
                  <span className="text-on-surface-variant font-medium">
                    Drag & drop files or <span className="text-primary">browse</span>
                  </span>
                  <span className="text-xs text-on-surface-variant/60 mt-1">PDF, PNG, JPG (Max 10MB)</span>
                  {files.length > 0 && (
                    <span className="text-xs text-primary mt-2 font-bold">
                      {files.length} file(s) selected
                    </span>
                  )}
                  <input
                    type="file"
                    className="hidden"
                    multiple
                    accept=".pdf,.png,.jpg,.jpeg"
                    onChange={handleFileChange}
                  />
                </label>
              </div>

              {/* Info Card */}
              <div className="bg-surface-container-low rounded-xl p-6 flex flex-col justify-center">
                <span className="material-symbols-outlined text-secondary mb-3" style={{ fontVariationSettings: "'FILL' 1" }}>
                  info
                </span>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Adding clear screenshots or documentation helps speed up the resolution process by{' '}
                  <span className="text-secondary font-bold">45%</span>.
                </p>
              </div>
            </div>
          </div>

          {/* Action Section */}
          <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-tertiary" style={{ fontVariationSettings: "'FILL' 1" }}>
                shield
              </span>
              <span className="text-xs text-on-surface-variant max-w-[200px]">
                Your data is encrypted and protected by Arbiter Trust protocols.
              </span>
            </div>
            <button
              type="submit"
              className="w-full md:w-auto px-10 py-4 rounded-full bg-gradient-to-br from-primary to-primary-container text-on-primary-container font-headline font-extrabold text-lg tracking-tight shadow-[0_0_20px_rgba(133,173,255,0.2)] hover:shadow-[0_0_30px_rgba(133,173,255,0.4)] transition-all scale-100 active:scale-95 flex items-center justify-center gap-2"
            >
              Submit Complaint
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
          </div>
        </form>
      </div>

      {/* Footer Help */}
      <div className="mt-12 flex items-center gap-8 text-on-surface-variant">
        <button className="flex items-center gap-2 hover:text-blue-300 transition-colors">
          <span className="material-symbols-outlined text-sm">help</span>
          <span className="text-sm font-medium">FAQ Center</span>
        </button>
        <div className="w-1 h-1 bg-outline-variant/30 rounded-full"></div>
        <button className="flex items-center gap-2 hover:text-blue-300 transition-colors">
          <span className="material-symbols-outlined text-sm">support_agent</span>
          <span className="text-sm font-medium">Live Support</span>
        </button>
      </div>
    </div>
  );
}
