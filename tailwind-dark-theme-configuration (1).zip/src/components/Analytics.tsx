import { useState, useEffect } from 'react';

interface Complaint {
  id: string;
  category: string;
  description: string;
  status: 'pending' | 'in-progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  files: string[];
}

export default function Analytics() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('complaints');
    if (stored) {
      setComplaints(JSON.parse(stored));
    }
  }, []);

  // Calculate category distribution
  const categoryStats = complaints.reduce((acc, complaint) => {
    acc[complaint.category] = (acc[complaint.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Calculate status distribution
  const statusStats = complaints.reduce((acc, complaint) => {
    acc[complaint.status] = (acc[complaint.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Calculate priority distribution
  const priorityStats = complaints.reduce((acc, complaint) => {
    acc[complaint.priority] = (acc[complaint.priority] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Calculate resolution rate
  const resolvedCount = complaints.filter(c => c.status === 'resolved' || c.status === 'closed').length;
  const resolutionRate = complaints.length > 0 ? Math.round((resolvedCount / complaints.length) * 100) : 0;

  // Average resolution time (mock data for demonstration)
  const avgResolutionDays = 3.2;

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold font-headline tracking-tighter text-on-surface mb-4">
          Analytics & Insights
        </h1>
        <p className="text-on-surface-variant text-lg">
          Data-driven insights into complaint patterns and resolution performance.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-green-400/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-green-400 text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                trending_up
              </span>
            </div>
            <div>
              <div className="text-4xl font-bold text-on-surface">{resolutionRate}%</div>
            </div>
          </div>
          <h3 className="text-on-surface font-semibold mb-1">Resolution Rate</h3>
          <p className="text-on-surface-variant text-sm">Successfully resolved complaints</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500/20 to-indigo-500/20 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-blue-400/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-blue-400 text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                schedule
              </span>
            </div>
            <div>
              <div className="text-4xl font-bold text-on-surface">{avgResolutionDays}</div>
            </div>
          </div>
          <h3 className="text-on-surface font-semibold mb-1">Avg. Resolution Time</h3>
          <p className="text-on-surface-variant text-sm">Days to resolve complaints</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full bg-purple-400/20 flex items-center justify-center">
              <span className="material-symbols-outlined text-purple-400 text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                groups
              </span>
            </div>
            <div>
              <div className="text-4xl font-bold text-on-surface">{complaints.length}</div>
            </div>
          </div>
          <h3 className="text-on-surface font-semibold mb-1">Total Cases</h3>
          <p className="text-on-surface-variant text-sm">All time complaint submissions</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
        {/* Category Distribution */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <h2 className="text-xl font-bold font-headline text-on-surface mb-6 flex items-center gap-2">
            <span className="material-symbols-outlined text-primary">pie_chart</span>
            Category Distribution
          </h2>
          {Object.keys(categoryStats).length === 0 ? (
            <div className="text-center py-12 text-on-surface-variant">
              No data available yet
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(categoryStats).map(([category, count]) => {
                const percentage = Math.round((count / complaints.length) * 100);
                return (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-on-surface capitalize font-medium">{category.replace('-', ' ')}</span>
                      <span className="text-on-surface-variant text-sm">{count} ({percentage}%)</span>
                    </div>
                    <div className="h-2 bg-surface-container-low rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary to-primary-container rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Status Distribution */}
        <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
          <h2 className="text-xl font-bold font-headline text-on-surface mb-6 flex items-center gap-2">
            <span className="material-symbols-outlined text-secondary">donut_small</span>
            Status Distribution
          </h2>
          {Object.keys(statusStats).length === 0 ? (
            <div className="text-center py-12 text-on-surface-variant">
              No data available yet
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(statusStats).map(([status, count]) => {
                const percentage = Math.round((count / complaints.length) * 100);
                const colors = {
                  pending: 'from-yellow-400 to-yellow-500',
                  'in-progress': 'from-blue-400 to-blue-500',
                  resolved: 'from-green-400 to-green-500',
                  closed: 'from-gray-400 to-gray-500'
                };
                return (
                  <div key={status}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-on-surface capitalize font-medium">{status.replace('-', ' ')}</span>
                      <span className="text-on-surface-variant text-sm">{count} ({percentage}%)</span>
                    </div>
                    <div className="h-2 bg-surface-container-low rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${colors[status as keyof typeof colors] || 'from-gray-400 to-gray-500'} rounded-full transition-all duration-500`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Priority Distribution */}
      <div className="bg-surface-bright/60 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10 shadow-[0_20px_40px_rgba(40,0,103,0.08)]">
        <h2 className="text-xl font-bold font-headline text-on-surface mb-6 flex items-center gap-2">
          <span className="material-symbols-outlined text-tertiary">flag</span>
          Priority Levels
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {['high', 'medium', 'low'].map((priority) => {
            const count = priorityStats[priority] || 0;
            const percentage = complaints.length > 0 ? Math.round((count / complaints.length) * 100) : 0;
            const colors = {
              high: { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-400/30' },
              medium: { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-400/30' },
              low: { bg: 'bg-green-500/10', text: 'text-green-400', border: 'border-green-400/30' }
            };
            const color = colors[priority as keyof typeof colors];
            return (
              <div key={priority} className={`${color.bg} border ${color.border} rounded-xl p-6`}>
                <div className="flex items-center justify-between mb-4">
                  <span className={`material-symbols-outlined ${color.text} text-3xl`} style={{ fontVariationSettings: "'FILL' 1" }}>
                    flag
                  </span>
                  <span className={`text-3xl font-bold ${color.text}`}>{count}</span>
                </div>
                <h3 className="text-on-surface font-semibold mb-1 capitalize">{priority} Priority</h3>
                <p className="text-on-surface-variant text-sm">{percentage}% of total cases</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Insights */}
      <div className="mt-12 bg-gradient-to-br from-primary/10 to-secondary/10 backdrop-blur-[24px] rounded-2xl p-8 border-t border-l border-white/10">
        <div className="flex items-start gap-4">
          <span className="material-symbols-outlined text-primary text-3xl" style={{ fontVariationSettings: "'FILL' 1" }}>
            lightbulb
          </span>
          <div>
            <h3 className="text-xl font-bold text-on-surface mb-2">Key Insights</h3>
            <ul className="space-y-2 text-on-surface-variant">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Adding documentation increases resolution speed by 45%</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Most complaints are categorized under service quality</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Average response time has improved by 28% this quarter</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
