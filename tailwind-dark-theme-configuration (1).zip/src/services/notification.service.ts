import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  query, 
  onSnapshot,
  orderBy,
  where,
  Timestamp,
  getDocs
} from 'firebase/firestore';
import { db } from './firebase';

export interface Notification {
  id?: string;
  message: string;
  type: 'new_complaint' | 'assignment' | 'status_update' | 'info';
  userEmail: string;
  read: boolean;
  createdAt: any;
  complaintId?: string;
}

export const createNotification = async (notification: Omit<Notification, 'id' | 'createdAt'>) => {
  const newNotification = {
    ...notification,
    createdAt: Timestamp.now()
  };
  
  const docRef = await addDoc(collection(db, 'notifications'), newNotification);
  return { id: docRef.id, ...newNotification };
};

export const markAsRead = async (id: string) => {
  const notificationRef = doc(db, 'notifications', id);
  await updateDoc(notificationRef, { read: true });
};

export const markAllAsRead = async (userEmail: string) => {
  const q = query(
    collection(db, 'notifications'),
    where('userEmail', '==', userEmail),
    where('read', '==', false)
  );
  
  const snapshot = await getDocs(q);
  const updates = snapshot.docs.map(doc => 
    updateDoc(doc.ref, { read: true })
  );
  
  await Promise.all(updates);
};

export const subscribeToNotifications = (
  userEmail: string,
  callback: (notifications: Notification[]) => void
) => {
  const q = query(
    collection(db, 'notifications'),
    where('userEmail', '==', userEmail),
    orderBy('createdAt', 'desc')
  );
  
  return onSnapshot(q, (snapshot) => {
    const notifications: Notification[] = [];
    snapshot.forEach((doc) => {
      notifications.push({ id: doc.id, ...doc.data() } as Notification);
    });
    callback(notifications);
  });
};
