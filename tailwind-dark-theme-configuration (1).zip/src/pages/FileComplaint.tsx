import { useState } from 'react';
import { motion } from 'framer-motion';
import { createComplaint, uploadComplaintImage } from '../services/complaint.service';
import { User, Mail, Phone, IdCard, Building2, Briefcase, FileText, MessageSquare, Upload, CheckCircle2, AlertCircle } from 'lucide-react';

const FileComplaint = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    employeeId: '',
    department: '',
    designation: '',
    category: '',
    title: '',
    description: '',
    priority: 'medium' as 'low' | 'medium' | 'high'
  });
  
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [complaintId, setComplaintId] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size should be less than 5MB');
        return;
      }
      
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file');
        return;
      }
      
      setImage(file);
      setImagePreview(URL.createObjectURL(file));
      setError('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validation
    if (!formData.name || !formData.email || !formData.phone || 
        !formData.employeeId || !formData.department || !formData.designation ||
        !formData.category || !formData.title || !formData.description) {
      setError('Please fill all required fields');
      return;
    }
    
    if (!image) {
      setError('Please attach an image');
      return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    setLoading(true);
    
    try {
      // Upload image first
      const imageUrl = await uploadComplaintImage(image);
      
      // Create complaint
      const result = await createComplaint({
        ...formData,
        category: formData.category as any,
        imageUrl
      });
      
      setComplaintId(result.id);
      setSuccess(true);
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        employeeId: '',
        department: '',
        designation: '',
        category: '',
        title: '',
        description: '',
        priority: 'medium'
      });
      setImage(null);
      setImagePreview('');
      
      // Hide success message after 5 seconds
      setTimeout(() => setSuccess(false), 5000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit complaint');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            File a Complaint
          </h1>
          <p className="text-slate-400 text-lg">
            Fill in the details below and we'll get back to you as soon as possible
          </p>
        </div>

        {/* Success Message */}
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 glass-card border-l-4 border-green-500 p-4 flex items-start gap-3"
          >
            <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-green-400 mb-1">Complaint Submitted Successfully!</h3>
              <p className="text-sm text-slate-300">
                Your complaint ID is: <span className="font-mono font-bold text-blue-400">{complaintId}</span>
              </p>
              <p className="text-sm text-slate-400 mt-1">
                Please save this ID for tracking your complaint.
              </p>
            </div>
          </motion.div>
        )}

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 glass-card border-l-4 border-red-500 p-4 flex items-start gap-3"
          >
            <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-400">Error</h3>
              <p className="text-sm text-slate-300">{error}</p>
            </div>
          </motion.div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="glass-card p-8">
          <div className="space-y-6">
            {/* Personal Information Section */}
            <div>
              <h2 className="text-xl font-bold mb-4 text-blue-400 flex items-center gap-2">
                <User className="w-5 h-5" />
                Personal Information
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Enter your email"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="Enter your phone number"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Employee ID */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Employee / Staff ID <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <IdCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      name="employeeId"
                      value={formData.employeeId}
                      onChange={handleChange}
                      placeholder="Enter your employee ID"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Department */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Department <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      name="department"
                      value={formData.department}
                      onChange={handleChange}
                      placeholder="Enter your department"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Designation */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Designation <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      name="designation"
                      value={formData.designation}
                      onChange={handleChange}
                      placeholder="Enter your designation"
                      className="glass-input pl-10"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Complaint Details Section */}
            <div>
              <h2 className="text-xl font-bold mb-4 text-purple-400 flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Complaint Details
              </h2>
              <div className="space-y-6">
                {/* Category */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="glass-input"
                    required
                  >
                    <option value="">Select a category</option>
                    <option value="Computer Complaint">Computer Complaint</option>
                    <option value="CCTV Complaint">CCTV Complaint</option>
                    <option value="Network Complaint">Network Complaint</option>
                    <option value="Others">Others</option>
                  </select>
                </div>

                {/* Title */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Complaint Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder="Brief title of your complaint"
                    className="glass-input"
                    required
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe your complaint in detail..."
                    rows={5}
                    className="glass-input resize-none"
                    required
                  />
                </div>

                {/* Priority */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Priority Level
                  </label>
                  <div className="flex gap-3">
                    {(['low', 'medium', 'high'] as const).map((priority) => (
                      <button
                        key={priority}
                        type="button"
                        onClick={() => setFormData({ ...formData, priority })}
                        className={`flex-1 py-3 rounded-lg font-medium transition-all ${
                          formData.priority === priority
                            ? priority === 'low'
                              ? 'bg-gradient-to-r from-green-500/20 to-green-600/20 border-2 border-green-500 text-green-400'
                              : priority === 'medium'
                              ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 border-2 border-yellow-500 text-yellow-400'
                              : 'bg-gradient-to-r from-red-500/20 to-red-600/20 border-2 border-red-500 text-red-400'
                            : 'glass-card hover:scale-105'
                        }`}
                      >
                        {priority.charAt(0).toUpperCase() + priority.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Image Upload */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                    <Upload className="w-4 h-4" />
                    Attach Image <span className="text-red-500">*</span>
                  </label>
                  <div className="glass-card p-6">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                      id="image-upload"
                      required
                    />
                    <label
                      htmlFor="image-upload"
                      className="flex flex-col items-center justify-center cursor-pointer"
                    >
                      {imagePreview ? (
                        <div className="relative w-full">
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="max-h-64 mx-auto rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              setImage(null);
                              setImagePreview('');
                            }}
                            className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-2 rounded-full"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <>
                          <Upload className="w-12 h-12 text-slate-400 mb-3" />
                          <p className="text-slate-300 font-medium mb-1">
                            Click to upload image
                          </p>
                          <p className="text-sm text-slate-500">
                            PNG, JPG, JPEG (Max 5MB)
                          </p>
                        </>
                      )}
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full glass-button py-4 text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    Submit Complaint
                  </>
                )}
              </button>
            </div>

            {/* Info */}
            <div className="glass-card p-4 border-l-4 border-blue-500">
              <p className="text-sm text-slate-300">
                <span className="font-semibold text-blue-400">Note:</span> All fields marked with{' '}
                <span className="text-red-500">*</span> are required. Your complaint will be reviewed by our team and you'll receive updates via email.
              </p>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default FileComplaint;
