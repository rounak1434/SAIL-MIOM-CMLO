import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { ProtectedRoute } from './components/ProtectedRoute';
import Home from './pages/Home';
import { Login } from './pages/Login';
import FileComplaint from './pages/FileComplaint';
import { TrackComplaint } from './pages/TrackComplaint';
import Dashboard from './pages/Dashboard';
import ModeratorDashboard from './pages/ModeratorDashboard';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-[#060e20] text-on-background font-body relative overflow-x-hidden">
          {/* Animated background orbs */}
          <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
            <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-secondary/10 blur-[120px] animate-pulse"></div>
            <div className="absolute top-[40%] -right-[10%] w-[50%] h-[50%] rounded-full bg-primary/5 blur-[100px] animate-pulse" style={{ animationDelay: '2s' }}></div>
            <div className="absolute bottom-[10%] left-[30%] w-[40%] h-[40%] rounded-full bg-tertiary/5 blur-[100px] animate-pulse" style={{ animationDelay: '4s' }}></div>
          </div>
          
          <Navbar />
          
          {/* Main content wrapper - no extra padding needed */}
          <main className="relative z-0">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/moderator-login" element={<Login />} />
              <Route path="/file-complaint" element={<FileComplaint />} />
              <Route path="/track-complaint" element={<TrackComplaint />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/moderator-dashboard"
                element={
                  <ProtectedRoute requiredRole="moderator">
                    <ModeratorDashboard />
                  </ProtectedRoute>
                }
              />

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
