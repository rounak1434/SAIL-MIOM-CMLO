import { useState } from 'react';
import { motion } from 'framer-motion';
import { getComplaintById, Complaint } from '../services/complaint.service';
import { Search, FileText, Clock, CheckCircle, AlertCircle } from 'lucide-react';

export const TrackComplaint = () => {
  const [complaintId, setComplaintId] = useState('');
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setComplaint(null);
    
    if (!complaintId.trim()) {
      setError('Please enter a complaint ID');
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await getComplaintById(complaintId.trim());
      
      if (result) {
        setComplaint(result);
      } else {
        setError('Complaint not found. Please check the ID and try again.');
      }
    } catch (err) {
      setError('Failed to fetch complaint. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'from-orange-500 to-yellow-500',
      assigned: 'from-blue-500 to-indigo-500',
      active: 'from-purple-500 to-pink-500',
      resolved: 'from-green-500 to-emerald-500',
      rejected: 'from-red-500 to-rose-500'
    };
    return colors[status] || colors.pending;
  };

  const getStatusIcon = (status: string) => {
    const icons: Record<string, any> = {
      pending: Clock,
      assigned: FileText,
      active: AlertCircle,
      resolved: CheckCircle,
      rejected: AlertCircle
    };
    return icons[status] || Clock;
  };

  return (
    <div className="min-h-screen pt-20 sm:pt-24 pb-12 px-4 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        {/* Header */}
        <div className="text-center mb-6 sm:mb-8 px-4">
          <h1 
            className="font-bold mb-3 sm:mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent leading-tight"
            style={{ fontSize: 'clamp(1.75rem, 6vw, 3rem)' }}
          >
            Track Your Complaint
          </h1>
          <p className="text-slate-300 text-sm sm:text-base md:text-lg leading-relaxed">
            Enter your complaint ID to check its current status
          </p>
        </div>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="glass-card p-4 sm:p-6 md:p-8 mb-6 sm:mb-8">
          <label className="block text-sm font-medium text-slate-300 mb-2 sm:mb-3">
            Complaint ID
          </label>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={complaintId}
                onChange={(e) => setComplaintId(e.target.value)}
                placeholder="Enter your complaint ID"
                className="glass-input pl-10 sm:pl-12 w-full text-white"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="glass-button w-full sm:w-auto px-6 sm:px-8 py-3 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium whitespace-nowrap min-w-[100px] min-h-[48px] rounded-xl flex items-center justify-center"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Search'
              )}
            </button>
          </div>
        </form>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 glass-card border-l-4 border-red-500 p-4 flex items-start gap-3"
          >
            <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-red-400">Error</h3>
              <p className="text-sm text-slate-300">{error}</p>
            </div>
          </motion.div>
        )}

        {/* Complaint Details */}
        {complaint && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Status Card */}
            <div className="relative">
              <div className={`absolute inset-0 bg-gradient-to-br ${getStatusColor(complaint.status)} rounded-2xl blur-xl opacity-30`} />
              <div className="relative glass-card p-8">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">Status</h3>
                    <div className="flex items-center gap-3">
                      {(() => {
                        const Icon = getStatusIcon(complaint.status);
                        return <Icon className="w-6 h-6 text-white" />;
                      })()}
                      <span className={`text-3xl font-bold bg-gradient-to-br ${getStatusColor(complaint.status)} bg-clip-text text-transparent capitalize`}>
                        {complaint.status}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-400 mb-1">Complaint ID</p>
                    <p className="font-mono text-lg text-white">{complaint.id}</p>
                  </div>
                </div>

                {/* Progress Timeline */}
                <div className="grid grid-cols-5 gap-2 mt-8">
                  {['pending', 'assigned', 'active', 'resolved'].map((status) => {
                    const isActive = 
                      status === complaint.status ||
                      (complaint.status === 'rejected' && status === 'pending');
                    const isPast = 
                      (complaint.status === 'assigned' && status === 'pending') ||
                      (complaint.status === 'active' && (status === 'pending' || status === 'assigned')) ||
                      (complaint.status === 'resolved' && status !== 'resolved');
                    
                    return (
                      <div key={status} className="flex flex-col items-center">
                        <div 
                          className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                            isActive 
                              ? `bg-gradient-to-br ${getStatusColor(status)} shadow-lg` 
                              : isPast
                              ? 'bg-green-500/30'
                              : 'bg-slate-700'
                          }`}
                        >
                          {isPast && <CheckCircle className="w-6 h-6 text-green-400" />}
                          {isActive && (() => {
                            const Icon = getStatusIcon(status);
                            return <Icon className="w-6 h-6 text-white" />;
                          })()}
                        </div>
                        <span className={`text-xs font-medium capitalize ${
                          isActive || isPast ? 'text-white' : 'text-slate-500'
                        }`}>
                          {status}
                        </span>
                      </div>
                    );
                  })}
                  <div className="flex flex-col items-center">
                    <div 
                      className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                        complaint.status === 'rejected'
                          ? 'bg-gradient-to-br from-red-500 to-rose-500 shadow-lg' 
                          : 'bg-slate-700'
                      }`}
                    >
                      <AlertCircle className={`w-6 h-6 ${complaint.status === 'rejected' ? 'text-white' : 'text-slate-500'}`} />
                    </div>
                    <span className={`text-xs font-medium ${
                      complaint.status === 'rejected' ? 'text-white' : 'text-slate-500'
                    }`}>
                      Rejected
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Details Grid */}
            <div className="glass-card p-8">
              <h3 className="text-2xl font-bold mb-6 text-white">Complaint Information</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Title</h4>
                  <p className="text-white font-medium">{complaint.title}</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Category</h4>
                  <p className="text-white font-medium">{complaint.category}</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Name</h4>
                  <p className="text-white">{complaint.name}</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Email</h4>
                  <p className="text-white">{complaint.email}</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Phone</h4>
                  <p className="text-white">{complaint.phone}</p>
                </div>
                <div>
                  <h4 className="text-sm text-slate-400 mb-2">Priority</h4>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    complaint.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                    complaint.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {complaint.priority.toUpperCase()}
                  </span>
                </div>
                <div className="md:col-span-2">
                  <h4 className="text-sm text-slate-400 mb-2">Description</h4>
                  <p className="text-white">{complaint.description}</p>
                </div>
                {complaint.assignedToName && (
                  <div className="md:col-span-2">
                    <h4 className="text-sm text-slate-400 mb-2">Assigned To</h4>
                    <p className="text-white font-medium">{complaint.assignedToName}</p>
                  </div>
                )}
                {complaint.imageUrl && (
                  <div className="md:col-span-2">
                    <h4 className="text-sm text-slate-400 mb-3">Attached Image</h4>
                    <img 
                      src={complaint.imageUrl} 
                      alt="Complaint" 
                      className="max-w-full rounded-lg"
                    />
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default TrackComplaint;
