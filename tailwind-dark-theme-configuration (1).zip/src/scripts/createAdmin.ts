/**
 * Script to create the initial admin user
 * Run this once after setting up Firebase
 * 
 * Usage:
 * 1. Ensure Firebase config is correct in src/services/firebase.ts
 * 2. Run: npm run create-admin (add this to package.json scripts)
 * 
 * Or manually create the user in Firebase Console:
 * - Go to Authentication > Users
 * - Add user with email: admin123@gmail.com, password: admin123
 * - Then add a document in Firestore:
 *   Collection: users
 *   Document ID: [user's UID from Authentication]
 *   Fields: { email: "admin123@gmail.com", role: "admin", displayName: "Administrator" }
 */

import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../services/firebase';

async function createAdminUser() {
  try {
    console.log('Creating admin user...');
    
    // Create authentication user
    const userCredential = await createUserWithEmailAndPassword(
      auth,
      'admin123@gmail.com',
      'admin123'
    );
    
    console.log('Admin user created in Authentication:', userCredential.user.uid);
    
    // Create user document in Firestore
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      email: 'admin123@gmail.com',
      role: 'admin',
      displayName: 'Administrator',
      createdAt: new Date().toISOString()
    });
    
    console.log('Admin user document created in Firestore');
    console.log('✅ Admin user created successfully!');
    console.log('Email: admin123@gmail.com');
    console.log('Password: admin123');
    
    process.exit(0);
  } catch (error: any) {
    console.error('❌ Error creating admin user:', error.message);
    
    if (error.code === 'auth/email-already-in-use') {
      console.log('ℹ️  Admin user already exists. You can use:');
      console.log('Email: admin123@gmail.com');
      console.log('Password: admin123');
    }
    
    process.exit(1);
  }
}

createAdminUser();
