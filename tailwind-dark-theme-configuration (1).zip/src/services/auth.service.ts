import { 
  signInWithEmailAndPassword, 
  signOut, 
  createUserWithEmailAndPassword,
  User
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from './firebase';

export interface UserRole {
  email: string;
  role: 'admin' | 'moderator';
  displayName?: string;
}

export const loginUser = async (email: string, password: string) => {
  try {
    // Trim whitespace to prevent login issues
    const cleanEmail = email.trim();
    const cleanPassword = password.trim();
    
    const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, cleanPassword);
    const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
    
    if (!userDoc.exists()) {
      await signOut(auth);
      throw new Error('User not authorized');
    }
    
    return { user: userCredential.user, role: userDoc.data() as UserRole };
  } catch (error: any) {
    console.error("Firebase Login Error:", error.code);
    
    if (error.code === 'auth/user-not-found') {
      throw new Error('User not found');
    }
    if (error.code === 'auth/wrong-password') {
      throw new Error('Incorrect password');
    }
    if (error.code === 'auth/invalid-email') {
      throw new Error('Invalid email');
    }
    if (error.code === 'auth/invalid-credential') {
      throw new Error('Invalid email or password');
    }
    
    throw new Error('Login failed. Please try again.');
  }
};

export const logoutUser = async () => {
  await signOut(auth);
};

export const createModerator = async (
  email: string, 
  password: string, 
  name: string,
  businessName?: string,
  phone?: string
) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      email,
      role: 'moderator',
      name,
      displayName: name,
      businessName: businessName || '',
      phone: phone || '',
      createdAt: new Date().toISOString()
    });
    
    // Sign out the newly created user to keep admin logged in
    await signOut(auth);
    
    return userCredential.user;
  } catch (error: any) {
    if (error.code === 'auth/email-already-in-use') {
      throw new Error('Email already in use');
    }
    throw error;
  }
};

export const getUserRole = async (user: User): Promise<UserRole | null> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists()) {
      return userDoc.data() as UserRole;
    }
    console.warn('User document not found in Firestore for UID:', user.uid);
    return null;
  } catch (error) {
    console.error('Error getting user role:', error);
    return null;
  }
};
